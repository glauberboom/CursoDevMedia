<div class="container">
    <div class="row">
        <br>
        <div class="col-md-12">
            <h3>Parabéns <?php echo $Sessao::retornaValorFormulario('nome');?>, seu cadastro foi realizado com sucesso.</h3>
            <a href="http://<?php echo APP_HOST; ?>/usuario/cadastro" class="btn btn-info">Voltar</a>
        </div>
    </div>
</div>