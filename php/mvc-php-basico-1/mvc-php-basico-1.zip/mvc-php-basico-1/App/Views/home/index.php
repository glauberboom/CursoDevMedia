<div class="container">
     <div class="starter-template">
            <h1>Primeira aplicação MVC em PHP</h1>
    </div>
</div>
