<?php 

class UsuarioModel
{
    public function UsuarioLogado()
    {
        return "Joel Rodrigues";
    }
}