<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
</head>
<body>
    <div class="container">
        <div class="jumbotron">
            <h1>Página inicial</h1>
            <a href="/?pagina=login">Login</a>
        </div>
    </div>
</body>
</html>